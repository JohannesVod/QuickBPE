from QuickBPE.regexFast import RegexTokenizerFast
from QuickBPE.fastfuncs import fastfuncs